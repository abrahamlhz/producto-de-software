<html>
	<head>
		<title>Administrar Libro</title>
	</head>	
	<body>
		<header>
			Bienvenido Administrar Libro
		</header>
		<table border=1>			
			<tr>
				<td><a href="ingresar.php">Ingresar</a></td>
			</tr>
			<tr>
				<td><a href="mostrar.php">Ver</a></td>
			</tr>
		</table>
		<footer>
			Administrar Libro 2017
		</footer>
	</body>
</html>